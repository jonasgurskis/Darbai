/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task3GUI;
import java.io.*;
/**
 *
 * @author PC
 */
public class Subject implements Serializable{// imanoma issaugoti duomenis i faila 
    private String title;
    private int creditsNr;

    public Subject(String title, int creditsNr) {
        this.title = title;
        this.creditsNr = creditsNr;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCreditsNr() {
        return creditsNr;
    }

    public void setCreditsNr(int creditsNr) {
        this.creditsNr = creditsNr;
    }
    
}
