/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task3GUI;
import java.io.*;

/**
 *
 * @author PC
 */
public class Grade implements Serializable{
    private String grades;
    private Student student;
    private Subject subject;

    public Grade(String grades, Student student, Subject subject) {
        this.grades = grades;
        this.student = student;
        this.subject = subject;
    }

    public String getGrades() {
        return grades;
    }

    public void setGrades(String grades) {
        this.grades = grades;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }
  
}
