/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Task3GUI;
import java.io.*;

/**
 *
 * @author PC
 */
public class Group implements Serializable{// imanoma issaugoti duomenis i faila 
    private String title;
    private int semester;


    public Group(String title, int semester) {
        this.title = title;
        this.semester = semester;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }
    
}
